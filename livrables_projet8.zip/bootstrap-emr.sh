#! /bin/bash
python3 -m pip install --user keras
python3 -m pip install --user pillow
python3 -m pip install --user pandas
